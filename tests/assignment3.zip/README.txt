This assignment was handed in by:
Karim Atta 10184696
Brandon White 10185441
Fang Xu 10183618
Dean Wilkins-Reeves 10176758


We divided the tests into the relative functions. For each function all you need to do is cd into the folder for the function and run 'bash functiontestscript.sh'